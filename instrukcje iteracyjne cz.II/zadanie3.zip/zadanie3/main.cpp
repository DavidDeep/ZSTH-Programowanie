#include <cstdlib>
#include <iostream>
#include <conio.h>
#include <math.h>

using namespace std;

int main(int argc, char *argv[])
{
   unsigned long int ulLiczba;
   int x = 1;
   cout << "Podaj liczbe: ";
   cin >> ulLiczba;
   unsigned long int ulFlaga = 1 << (sizeof(ulLiczba)* 8 - 1);
   for(; ulFlaga > 0; ulFlaga >>= 1)
      printf("%d",ulLiczba & ulFlaga ? 1 : 0);
      getch();
}

